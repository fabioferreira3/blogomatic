<?php
include plugin_dir_path(__FILE__) . '/FTP/FTP_upload.php';
include plugin_dir_path(__FILE__) . '/Local/Local_upload.php';
include plugin_dir_path(__FILE__) . '/Email/Email_upload.php';
include plugin_dir_path(__FILE__) . '/Google/Google_upload.php';
include plugin_dir_path(__FILE__) . '/S3/S3_upload.php';
include plugin_dir_path(__FILE__) . '/Dropbox/Dropbox_upload.php';